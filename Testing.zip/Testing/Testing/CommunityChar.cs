﻿//Attempt 1

using Microsoft.ML.Probabilistic.Models;

namespace Testing
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Collections.Generic;
    using Microsoft.ML.Probabilistic.Algorithms;
    using Microsoft.ML.Probabilistic.Compiler.Visualizers;
    using Microsoft.ML.Probabilistic.Distributions;
    using Microsoft.ML.Probabilistic.Math;
    using Microsoft.ML.Probabilistic.Utilities;
    using Range = Range;
    using Microsoft.ML.Probabilistic.Models.Attributes;
    using GaussianArray = Microsoft.ML.Probabilistic.Distributions.DistributionStructArray<Microsoft.ML.Probabilistic.Distributions.Gaussian, double>;
    using GaussianArrayArray =
        Microsoft.ML.Probabilistic.Distributions.DistributionRefArray<Microsoft.ML.Probabilistic.Distributions.DistributionStructArray<Microsoft.ML.Probabilistic.Distributions.Gaussian, double>, double[]>;

    public class CommunityCharModel
    {
        //Defining variables
        public VariableArray<int> Community;    // Error communities
        public VariableArray<int> Motivation;   // Paid, Volunteer
        public VariableArray<int> Recruitment;  // Outreach, Personal connection, Random visit, Social media 
        public VariableArray<int> Age;          // <=18, 19-25, >25
        public VariableArray<int> Education;    // <Bachelors, Bachelors, >Bachelors
        public VariableArray<int> Occupation;   // Student, Agriculture, Other
        public VariableArray<int> RuralUrban;   // Rural, Urban, Semi-Urban
        public VariableArray<int> Gender;       // Male, Female
        public VariableArray<int> Ability;      // Performance ratio from Davids et al. (2019)
        public VariableArray<int> Experience;   // Number of submissions
        public VariableArray<VariableArray<int>, int[][]> Error;    // No Error(0), Unit Error(1), Meniscus Error(2), Unknown Error(3)
        public VariableArray<int> CitizenSciID;                     // Unique ID for citizen scientists
        public VariableArray<double> TrueValue;                     // Rainfall value from the submitted photo
        public VariableArray<double> aSlope;                        // Slope of the regression equation
        public VariableArray<double> bInt;                          // Intercept of the regression equation
        public VariableArray<double> Precs;                         // Precision of the gaussian for the regression
        public VariableArray<double> alphaPrior;                    // Shape parameter for the gamma prior for the Precs variable
        public VariableArray<double> betaPrior;                     // Scale parameter for the gamma prior for the Precs variable  
        public Variable<int> CSISizeVar;                            // Number of CS; outer index for jaggedCSObs array   
        public VariableArray<int> CSObsSizesVar;                    // Number of observations that each CS has submitted; inner index for jaggedCSObs array
        public VariableArray<VariableArray<double>, double[][]> jaggedCSObs;    // Value of submitted observation
        public VariableArray<VariableArray<int>, int[][]> CSEindex;             // Indexes each event

        // Random variables representing the parameters of the distributions
        // of the primary random variables. For child variables, these are
        // in the form of conditional probability tables (CPTs)
        public Variable<Vector> ProbCommunity;
        public VariableArray<Discrete> CommunityPrior;
        public VariableArray<Vector> CPTError;
        public VariableArray<Vector> CPTMotivation;
        public VariableArray<Vector> CPTRecruitment;
        public VariableArray<Vector> CPTAge;
        public VariableArray<Vector> CPTEducation;
        public VariableArray<Vector> CPTOccupation;
        public VariableArray<Vector> CPTRuralUrban;
        public VariableArray<Vector> CPTGender;
        public VariableArray<Vector> CPTAbility;
        public VariableArray<Vector> CPTExperience;

        // Prior distributions
        public Variable<Dirichlet> ProbCommunityPrior;
        public VariableArray<Dirichlet> CPTErrorPrior;
        public VariableArray<Gaussian> TrueValuePrior;
        public VariableArray<VariableArray<Gaussian>, Gaussian[][]> CSObservationPrior;
        public VariableArray<Dirichlet> CPTMotivationPrior;
        public VariableArray<Dirichlet> CPTRecruitmentPrior;
        public VariableArray<Dirichlet> CPTAgePrior;
        public VariableArray<Dirichlet> CPTEducationPrior;
        public VariableArray<Dirichlet> CPTOccupationPrior;
        public VariableArray<Dirichlet> CPTRuralUrbanPrior;
        public VariableArray<Dirichlet> CPTGenderPrior;
        public VariableArray<Dirichlet> CPTAbilityPrior;
        public VariableArray<Dirichlet> CPTExperiencePrior;
        public VariableArray<Gaussian> aSlopePrior;
        public VariableArray<Gaussian> bIntPrior;
        public VariableArray<Gamma> PrecsPrior;

        // Posterior distributions
        public Dirichlet ProbCommunityPosterior;
        public Discrete[] CommunityPosterior;
        public Dirichlet[] CPTErrorPosterior;
        public Gaussian[] TrueValuePosterior;
        public Gaussian[][] CSobservationPosterior;
        public Dirichlet[] CPTMotivationPosterior;
        public Dirichlet[] CPTRecruitmentPosterior;
        public Dirichlet[] CPTAgePosterior;
        public Dirichlet[] CPTEducationPosterior;
        public Dirichlet[] CPTOccupationPosterior;
        public Dirichlet[] CPTRuralUrbanPosterior;
        public Dirichlet[] CPTGenderPosterior;
        public Dirichlet[] CPTAbilityPosterior;
        public Dirichlet[] CPTExperiencePosterior;
        public Gaussian[] aSlopePosterior;
        public Gaussian[] bIntPosterior;
        public Gamma[] PrecsPosterior;
        public Discrete[][] ErrorPosterior;

        //// Model evidence variable
        public Variable<bool> evidence;
        public IfBlock block;

        public Variable<IDistribution<int[]>> CSCommunityInitializer { get; set; }
        public Range CSI { get; set; }    // Citizen Scientist IDs
        public Range Er { get; set; }     // Error range
        //public Range Er4 { get; set; }     // Error range without outliers
        public Range CSObs { get; set; }  // Range of submitted Citizen Scientist Observations
        public Range C { get; set; }      // Range of communities
        public Range Event { get; set; }   // Range of events
        public Range CSE { get; set; }     // Range of indicator variable

        // Inference engine
        public InferenceEngine Engine = new InferenceEngine(new ExpectationPropagation());

        /// <summary>
        /// Constructs a Community/Characteristic model
        /// </summary>
        public void CreateCommunityCharModel(int numCommunity,
        int numMotivation,
        int numRecruitment,
        int numAge,
        int numEducation,
        int numOccupation,
        int numRuralUrban,
        int numGender,
        int numAbility,
        int numExperience,
        int numError,
        int numCitizens,
        int numEvents)
        {
            //evidence = Variable.Bernoulli(0.5).Named("evidence");
            //block = Variable.If(evidence);

            // Setting up ranges
            Event = new Range(numEvents).Named("Event");       // Event Count
            Er = new Range(numError).Named("Er");                   // Range of Error types
            C = new Range(numCommunity).Named("C");                 // Communities
            Range M = new Range(numMotivation).Named("M");          // Motivation
            Range R = new Range(numRecruitment).Named("R");         // Recruitment
            Range A = new Range(numAge).Named("A");                 // Age
            Range E = new Range(numEducation).Named("E");           // Education
            Range O = new Range(numOccupation).Named("O");          // Occupation
            Range Ru = new Range(numRuralUrban).Named("Ru");        // RuralUrban
            Range G = new Range(numGender).Named("G");              // Gender
            Range Ab = new Range(numAbility).Named("Ab");           // Ability
            Range Ex = new Range(numExperience).Named("Ex");        // Experience

            // Setting up the ranges for a jagged array (for Error variable)
            CSISizeVar = Variable.New<int>().Named("CSISizeVar");
            CSI = new Range(CSISizeVar).Named("CSI");
            CSObsSizesVar = Variable.Array<int>(CSI).Named("CSObsSizesVar");
            CSObs = new Range(CSObsSizesVar[CSI]).Named("CSObs");

            jaggedCSObs = Variable.Array(Variable.Array<double>(CSObs), CSI).Named("jaggedCSObs");

            CSEindex = Variable.Array(Variable.Array<int>(CSObs), CSI).Named("CSEindex");
            CSEindex.SetValueRange(Event);

            // Define the priors and the parameters
            ProbCommunityPrior = Variable.New<Dirichlet>().Named("ProbCommunityPrior");
            ProbCommunity=Variable<Vector>.Random(ProbCommunityPrior).Named("ProbCommunity");
            //ProbCommunity.AddAttribute(new TraceMessages());
            ProbCommunity.SetValueRange(C);

            Community = Variable.Array<int>(CSI).Named("Community");
            //Community.AddAttribute(new TraceMessages());
            Community[CSI] = Variable.Discrete(ProbCommunity).ForEach(CSI);
            Community.SetValueRange(C);

            // Symmetry breaking
            CSCommunityInitializer = Variable.New<IDistribution<int[]>>().Named("CSCommunityInitializer");
            Community.InitialiseTo(CSCommunityInitializer);

            // True Value probability
            TrueValuePrior = Variable.Array<Gaussian>(Event).Named("TrueValuePrior");
            TrueValue = Variable.Array<double>(Event).Named("TrueValue");
            TrueValue[Event] = Variable<double>.Random(TrueValuePrior[Event]);

            // CSObs probability
            CSObservationPrior = Variable.Array(Variable.Array<Gaussian>(CSObs), CSI).Named("CSObservationPrior");
            jaggedCSObs = Variable.Array(Variable.Array<double>(CSObs), CSI).Named("jaggedCSObs");
            //jaggedCSObs[CSI][CSObs] = Variable<double>.Random(CSObservationPrior[CSI][CSObs]);

            // Error probability table conditioned on community and SubmittedObservation
            CPTErrorPrior = Variable.Array<Dirichlet>(C).Named("CPTErrorPrior");
            CPTError = Variable.Array<Vector>(C).Named("CPTError");
            //CPTError.AddAttribute(new TraceMessages());
            CPTError[C] = Variable<Vector>.Random(CPTErrorPrior[C]);
            CPTError.SetValueRange(Er);

            Error = Variable.Array(Variable.Array<int>(CSObs), CSI).Named("Error");
            //Error.AddAttribute(new TraceMessages());
            Error.SetValueRange(Er);

            // Motivation probability table conditioned on community
            CPTMotivationPrior = Variable.Array<Dirichlet>(C).Named("CPTMotivationPrior");
            CPTMotivation = Variable.Array<Vector>(C).Named("CPTMotivation");
            CPTMotivation[C] = Variable<Vector>.Random(CPTMotivationPrior[C]);
            CPTMotivation.SetValueRange(M);

            // Recruitment probability table conditioned on community
            CPTRecruitmentPrior = Variable.Array<Dirichlet>(C).Named("CPTRecruitmentPrior");
            CPTRecruitment = Variable.Array<Vector>(C).Named("CPTRecruitment");
            CPTRecruitment[C] = Variable<Vector>.Random(CPTRecruitmentPrior[C]);
            CPTRecruitment.SetValueRange(R);

            // Age probability table conditioned on community
            CPTAgePrior = Variable.Array<Dirichlet>(C).Named("CPTAgePrior");
            CPTAge = Variable.Array<Vector>(C).Named("CPTAge");
            CPTAge[C] = Variable<Vector>.Random(CPTAgePrior[C]);
            CPTAge.SetValueRange(A);

            // Education probability table conditioned on community
            CPTEducationPrior = Variable.Array<Dirichlet>(C).Named("CPTEducationPrior");
            CPTEducation = Variable.Array<Vector>(C).Named("CPTEducation");
            CPTEducation[C] = Variable<Vector>.Random(CPTEducationPrior[C]);
            CPTEducation.SetValueRange(E);

            // Occupation probability table conditioned on community
            CPTOccupationPrior = Variable.Array<Dirichlet>(C).Named("CPTOccupationPrior");
            CPTOccupation = Variable.Array<Vector>(C).Named("CPTOccupation");
            CPTOccupation[C] = Variable<Vector>.Random(CPTOccupationPrior[C]);
            CPTOccupation.SetValueRange(O);

            // RuralUrban probability table conditioned on community
            CPTRuralUrbanPrior = Variable.Array<Dirichlet>(C).Named("CPTRuralUrbanPrior");
            CPTRuralUrban = Variable.Array<Vector>(C).Named("CPTRuralUrban");
            CPTRuralUrban[C] = Variable<Vector>.Random(CPTRuralUrbanPrior[C]);
            CPTRuralUrban.SetValueRange(Ru);

            // Gender probability table conditioned on community
            CPTGenderPrior = Variable.Array<Dirichlet>(C).Named("CPTGenderPrior");
            CPTGender = Variable.Array<Vector>(C).Named("CPTGender");
            CPTGender[C] = Variable<Vector>.Random(CPTGenderPrior[C]);
            CPTGender.SetValueRange(G);

            // Ability probability table conditioned on community
            CPTAbilityPrior = Variable.Array<Dirichlet>(C).Named("CPTAbilityPrior");
            CPTAbility = Variable.Array<Vector>(C).Named("CPTAbility");
            CPTAbility[C] = Variable<Vector>.Random(CPTAbilityPrior[C]);
            CPTAbility.SetValueRange(Ab);

            // Experience probability table conditioned on community
            CPTExperiencePrior = Variable.Array<Dirichlet>(C).Named("CPTExperiencePrior");
            CPTExperience = Variable.Array<Vector>(C).Named("CPTExperience");
            CPTExperience[C] = Variable<Vector>.Random(CPTExperiencePrior[C]);
            CPTExperience.SetValueRange(Ex);

            // Define the structure/primary variables
            Motivation = AddChildFromOneParent(Community, CPTMotivation).Named("Motivation");
            Recruitment = AddChildFromOneParent(Community, CPTRecruitment).Named("Recruitment");
            Age = AddChildFromOneParent(Community, CPTAge).Named("Age");
            Education = AddChildFromOneParent(Community, CPTEducation).Named("Education");
            Occupation = AddChildFromOneParent(Community, CPTOccupation).Named("Occupation");
            RuralUrban = AddChildFromOneParent(Community, CPTRuralUrban).Named("RuralUrban");
            Gender = AddChildFromOneParent(Community, CPTGender).Named("Gender");
            Ability = AddChildFromOneParent(Community, CPTAbility).Named("Ability");
            Experience = AddChildFromOneParent(Community, CPTExperience).Named("Experience");

            /// <Summary>
            /// Make the switch around the Error variable
            /// </Summary>
            using (Variable.ForEach(CSI))
            {
                using (Variable.Switch(Community[CSI]))
                {
                    using (Variable.ForEach(CSObs))
                    {
                        Error[CSI][CSObs] = Variable.Discrete(CPTError[Community[CSI]]);
                    }
                }
            }

            /// <Summary>
            /// Make the switch around the Regression factor node
            /// Number of mixture components = Er
            /// </Summary>
            // Mixture components a,b
            aSlope = Variable.Array<double>(Er).Named("aSlope");
            //aSlope.AddAttribute(new TraceMessages());
            aSlopePrior = Variable.Array<Gaussian>(Er).Named("aSlopePrior");
            aSlope[Er] = Variable<double>.Random(aSlopePrior[Er]);

            bInt = Variable.Array<double>(Er).Named("bInt");
            //bInt.AddAttribute(new TraceMessages());
            bIntPrior = Variable.Array<Gaussian>(Er).Named("bIntPrior");
            bInt[Er] = Variable<double>.Random(bIntPrior[Er]);

            // Mixture component precisions
            Precs = Variable.Array<double>(Er).Named("Precs");
            //Precs.AddAttribute(new TraceMessages());
            PrecsPrior = Variable.Array<Gamma>(Er).Named("PrecsPrior");
            Precs[Er] = Variable<double>.Random(PrecsPrior[Er]);

            // Mixture weights are defined by the Error posterior
            // The mixture of Gaussians model
            using (Variable.ForEach(CSI))
            {
                using (Variable.ForEach(CSObs))
                {
                    using (Variable.Switch(Error[CSI][CSObs]))
                    {
                        jaggedCSObs[CSI][CSObs] = Variable.GaussianFromMeanAndPrecision(aSlope[Error[CSI][CSObs]] * TrueValue[CSEindex[CSI][CSObs]] + bInt[Error[CSI][CSObs]], Precs[Error[CSI][CSObs]]);
                    }
                }
            }
            //block.CloseBlock();
        }

        /// <summary>
        /// Learns the parameters of CommunityCharModel
        /// </summary>
        // Might be a helpful alternative example 
        // https://social.microsoft.com/Forums/en-US/f9c91b9b-7583-4069-a4aa-903618754657/on-learning-parameters-from-data-migrated-from-communityresearchmicrosoftcom?forum=infer.net
        public void LearnParameters(
        //int[] community,
        string RunType,     // "train" or "test"
        int[] motivation,
        int[] recruitment,
        int[] age,
        int[] education,
        int[] occupation,
        int[] ruralurban,
        int[] gender,
        int[] ability,
        int[] experience,
        int[][] error,
        double[][] jaggedCSO,
        double[] csObservation,
        double[] csObservation_test,
        double[] alphaprior, // for training data
        double[] betaprior,
        double meantvprior,
        double vartvprior,
        double[] meanaprior,
        double[] varaprior,
        double[] meanbprior,
        double[] varbprior,
        double[] Truevalue, // end for training data
        double[] Truevalue_test,
        int[][] cseIndex, 
        Dirichlet probCommunityPosterior,  // for testing data
        Dirichlet[] cptMotivationPosterior,
        Dirichlet[] cptRecruitmentPosterior,
        Dirichlet[] cptAgePosterior,
        Dirichlet[] cptEducationPosterior,
        Dirichlet[] cptOccupationPosterior,
        Dirichlet[] cptRuralUrbanPosterior,
        Dirichlet[] cptGenderPosterior,
        Dirichlet[] cptAbilityPosterior,
        Dirichlet[] cptExperiencePosterior,
        Dirichlet[] cptErrorPosterior,
        Gaussian[] trueValuePosterior,
        Gaussian[] aSlopePosterior_,
        Gaussian[] bIntPosterior_,
        Gamma[] PrecsPosterior_)   // end for testing data

        {
            // Set the observations
            //Community.ObservedValue community;
            Motivation.ObservedValue = motivation;
            Recruitment.ObservedValue = recruitment;
            Age.ObservedValue = age;
            Education.ObservedValue = education;
            Occupation.ObservedValue = occupation;
            RuralUrban.ObservedValue = ruralurban;
            Gender.ObservedValue = gender;
            Ability.ObservedValue = ability;
            Experience.ObservedValue = experience;
            CSEindex.ObservedValue = cseIndex;
            
            // Set the uniform priors for the probability tables
            int numCommunity = Community.GetValueRange().SizeAsInt;
            int numMotivation = Motivation.GetValueRange().SizeAsInt;
            int numRecruitment = Recruitment.GetValueRange().SizeAsInt;
            int numAge = Age.GetValueRange().SizeAsInt;
            int numEducation = Education.GetValueRange().SizeAsInt;
            int numOccupation = Occupation.GetValueRange().SizeAsInt;
            int numRuralUrban = RuralUrban.GetValueRange().SizeAsInt;
            int numGender = Gender.GetValueRange().SizeAsInt;
            int numAbility = Ability.GetValueRange().SizeAsInt;
            int numExperience = Experience.GetValueRange().SizeAsInt;
            int numError = Error.GetValueRange().SizeAsInt;
            int numEvents = CSEindex.GetValueRange().SizeAsInt;
            int numCS = motivation.Length; 
            int numTV_train = Truevalue.Length; // for estimating truevalueprior for test

            if (RunType == "train")
            {
                // Set Observations for training
                //Error.ObservedValue = error;
                TrueValue.ObservedValue = Truevalue;

                // Create variables to hold uniform priors
                Dirichlet[] cptMotivationPrior = new Dirichlet[numCommunity];
                Dirichlet[] cptRecruitmentPrior = new Dirichlet[numCommunity];
                Dirichlet[] cptAgePrior = new Dirichlet[numCommunity];
                Dirichlet[] cptEducationPrior = new Dirichlet[numCommunity];
                Dirichlet[] cptOccupationPrior = new Dirichlet[numCommunity];
                Dirichlet[] cptRuralUrbanPrior = new Dirichlet[numCommunity];
                Dirichlet[] cptGenderPrior = new Dirichlet[numCommunity];
                Dirichlet[] cptAbilityPrior = new Dirichlet[numCommunity];
                Dirichlet[] cptExperiencePrior = new Dirichlet[numCommunity];
                Dirichlet[] cptErrorPrior = new Dirichlet[numCommunity];
                Gaussian[] Truevalueprior = new Gaussian[numEvents];
                Gaussian[] aSlopeprior = new Gaussian[numError];
                Gaussian[] bIntprior = new Gaussian[numError];
                Gamma[] precsPrior = new Gamma[numError];

                // Assign uniform priors to variables
                Dirichlet probCommunityPrior = Dirichlet.Uniform(numCommunity);
                for (int i = 0; i < numCommunity; i++)
                {
                    cptMotivationPrior[i] = Dirichlet.Uniform(numMotivation);
                    cptRecruitmentPrior[i] = Dirichlet.Uniform(numRecruitment);
                    cptAgePrior[i] = Dirichlet.Uniform(numAge);
                    cptEducationPrior[i] = Dirichlet.Uniform(numEducation);
                    cptOccupationPrior[i] = Dirichlet.Uniform(numOccupation);
                    cptRuralUrbanPrior[i] = Dirichlet.Uniform(numRuralUrban);
                    cptGenderPrior[i] = Dirichlet.Uniform(numGender);
                    cptAbilityPrior[i] = Dirichlet.Uniform(numAbility);
                    cptExperiencePrior[i] = Dirichlet.Uniform(numExperience);
                    cptErrorPrior[i] = Dirichlet.Uniform(numError);
                }
                for (int j = 0; j < numEvents; j++)
                {
                    Truevalueprior[j] = Gaussian.FromMeanAndPrecision(meantvprior, 1 / vartvprior);
                }
                for (int t = 0; t < (numError); t++)
                {
                    aSlopeprior[t] = Gaussian.FromMeanAndPrecision(meanaprior[t], 1 / varaprior[t]);
                    bIntprior[t] = Gaussian.FromMeanAndPrecision(meanbprior[t], 1 / varbprior[t]);
                    precsPrior[t] = Gamma.FromShapeAndRate(alphaprior[t], betaprior[t]);
                }

                Console.WriteLine("Observing Training Parameters");

                CSISizeVar.ObservedValue = jaggedCSO.Length;
                var CSObsSizes1 = new int[jaggedCSO.Length];
                for (int i = 0; i < jaggedCSO.Length; i++)
                    CSObsSizes1[i] = jaggedCSO[i].Length;
                CSObsSizesVar.ObservedValue = CSObsSizes1;
                jaggedCSObs.ObservedValue = jaggedCSO;

                // Observe the uniform priors
                ProbCommunityPrior.ObservedValue = probCommunityPrior;
                //CommunityPrior.ObservedValue = Util.ArrayInit(numCS, w => Discrete.Uniform(numCommunity));
                CPTMotivationPrior.ObservedValue = cptMotivationPrior;
                CPTRecruitmentPrior.ObservedValue = cptRecruitmentPrior;
                CPTAgePrior.ObservedValue = cptAgePrior;
                CPTEducationPrior.ObservedValue = cptEducationPrior;
                CPTOccupationPrior.ObservedValue = cptOccupationPrior;
                CPTRuralUrbanPrior.ObservedValue = cptRuralUrbanPrior;
                CPTGenderPrior.ObservedValue = cptGenderPrior;
                CPTAbilityPrior.ObservedValue = cptAbilityPrior;
                CPTExperiencePrior.ObservedValue = cptExperiencePrior;
                CPTErrorPrior.ObservedValue = cptErrorPrior;
                TrueValuePrior.ObservedValue = Truevalueprior;
                aSlopePrior.ObservedValue = aSlopeprior;
                bIntPrior.ObservedValue = bIntprior;
                PrecsPrior.ObservedValue = precsPrior;
                CSObservationPrior.ObservedValue = Util.ArrayInit(numCS, u => Util.ArrayInit(CSObsSizes1[u], t => Gaussian.FromMeanAndPrecision(meantvprior, 1 / vartvprior)));
            }
            else
            {
                Console.WriteLine("Observing Test Parameters");
                //Error.AddAttribute(new TraceMessages());
                // Observe trained posteriors for testing model performance
                ProbCommunityPrior.ObservedValue = probCommunityPosterior;
                //CommunityPrior.ObservedValue = CommunityPosterior;
                CPTMotivationPrior.ObservedValue = cptMotivationPosterior;
                CPTRecruitmentPrior.ObservedValue = cptRecruitmentPosterior;
                CPTAgePrior.ObservedValue = cptAgePosterior;
                CPTEducationPrior.ObservedValue = cptEducationPosterior;
                CPTOccupationPrior.ObservedValue = cptOccupationPosterior;
                CPTRuralUrbanPrior.ObservedValue = cptRuralUrbanPosterior;
                CPTGenderPrior.ObservedValue = cptGenderPosterior;
                CPTAbilityPrior.ObservedValue = cptAbilityPosterior;
                CPTExperiencePrior.ObservedValue = cptExperiencePosterior;
                CPTErrorPrior.ObservedValue = cptErrorPosterior;
                //aSlopePrior.ObservedValue = aSlopePosterior_;
                aSlopePrior.ObservedValue = Util.ArrayInit(aSlopePosterior_.Length, i => Gaussian.PointMass(aSlopePosterior_[i].GetMean()));
                bIntPrior.ObservedValue = bIntPosterior_;
                PrecsPrior.ObservedValue = PrecsPosterior_;

                Gaussian[] Truevalueprior = new Gaussian[numEvents];
                GaussianEstimator est = new GaussianEstimator();
                for (int i = 0; i < numTV_train; i++)
                {
                    double stv = Truevalue[i];
                    est.Add(stv);
                }
                for (int j = 0; j < numEvents; j++)
                {
                    Truevalueprior[j] = est.GetDistribution(new Gaussian());
                }
                TrueValuePrior.ObservedValue = Truevalueprior;
                Truevalue = Truevalue_test;

                CSISizeVar.ObservedValue = jaggedCSO.Length;
                var CSObsSizes1 = new int[jaggedCSO.Length];
                for (int i = 0; i < jaggedCSO.Length; i++)
                    CSObsSizes1[i] = jaggedCSO[i].Length;
                CSObsSizesVar.ObservedValue = CSObsSizes1;
                           
                //Gaussian[][] CSObsprior = new Gaussian[numCS][];
                GaussianEstimator est1 = new GaussianEstimator();
                for (int i = 0; i < numTV_train; i++)
                {
                    double stv1 = csObservation[i];
                    est1.Add(stv1);
                }
                //for (int j = 0; j < numCS; j++)
                //{
                //    for (int k = 0; k < CSObsSizes1[j]; k++)
                //    {
                //        CSObsprior[j][k] = est1.GetDistribution(new Gaussian());
                //    }
                    
                //}
                //CSObservationPrior.ObservedValue = CSObsprior;
                CSObservationPrior.ObservedValue=Util.ArrayInit(numCS, u => Util.ArrayInit(CSObsSizes1[u], t => est1.GetDistribution(new Gaussian())));

            }

            //The observed values can then be set before inference, making sure that the jagged sizes, and the jagged array itself are consistently set:
            //Set in the learn parameters phase.
            CSISizeVar.ObservedValue = jaggedCSO.Length;
            var CSObsSizes = new int[jaggedCSO.Length];
            for (int i = 0; i < jaggedCSO.Length; i++)
                CSObsSizes[i] = jaggedCSO[i].Length;
            CSObsSizesVar.ObservedValue = CSObsSizes;
            //jaggedCSObs.ObservedValue = jaggedCSO;
            TrueValue.ObservedValue = Truevalue;

            // Initialize messages
            Rand.Restart(12347);
            var discreteUniform = Discrete.Uniform(numCommunity);
            CSCommunityInitializer.ObservedValue = Distribution<int>.Array(Util.ArrayInit(jaggedCSO.Length, w => Discrete.PointMass(discreteUniform.Sample(), numCommunity)));

            // Inference Settings
            Engine.ShowProgress = true;
            Engine.ShowTimings = false;
            Engine.ShowMsl = false;
            Engine.ShowFactorGraph = false; //Turning this on slows down the program significantly.
            Engine.ShowSchedule = false;
            Engine.SaveFactorGraphToFolder = "graphs";
            Engine.NumberOfIterations = 20;

            //Compute model evidence. Used to determine the number of parameters
            //if (RunType == "train")
            //{
            //    double logEvidence = Engine.Infer<Bernoulli>(evidence).LogOdds;
            //    Console.WriteLine("Evidence: " + logEvidence);
            //    //Console.WriteLine("Model Evidence....." + Math.Exp(logEvidence));
            //}

            Console.WriteLine("Performing Inference " + RunType);
            // Perform inference
            Console.WriteLine("Inferring  ProbCommunity");
                ProbCommunityPosterior = Engine.Infer<Dirichlet>(ProbCommunity);
            Console.WriteLine("Inferring Community");
                CommunityPosterior = Engine.Infer<Discrete[]>(Community);
            Console.WriteLine("Inferring TV");
            //TrueValuePosterior = Engine.Infer<Gaussian[]>(TrueValue);
            CSobservationPosterior = Engine.Infer<Gaussian[][]>(jaggedCSObs);
                CPTMotivationPosterior = Engine.Infer<Dirichlet[]>(CPTMotivation);
                CPTRecruitmentPosterior = Engine.Infer<Dirichlet[]>(CPTRecruitment);
                CPTAgePosterior = Engine.Infer<Dirichlet[]>(CPTAge);
                CPTEducationPosterior = Engine.Infer<Dirichlet[]>(CPTEducation);
                CPTOccupationPosterior = Engine.Infer<Dirichlet[]>(CPTOccupation);
                CPTRuralUrbanPosterior = Engine.Infer<Dirichlet[]>(CPTRuralUrban);
                CPTGenderPosterior = Engine.Infer<Dirichlet[]>(CPTGender);
                CPTAbilityPosterior = Engine.Infer<Dirichlet[]>(CPTAbility);
                CPTExperiencePosterior = Engine.Infer<Dirichlet[]>(CPTExperience);
                CPTErrorPosterior = Engine.Infer<Dirichlet[]>(CPTError);
                aSlopePosterior = Engine.Infer<Gaussian[]>(aSlope);
                bIntPosterior = Engine.Infer<Gaussian[]>(bInt);
                PrecsPosterior = Engine.Infer<Gamma[]>(Precs);
                ErrorPosterior = Engine.Infer<Discrete[][]>(Error);
        }

        /// <summary>
        /// Helper method to add a child from one parent
        /// </summary>
        /// <param name="parent">Parent (a variable array over a range of examples)</param>
        /// <param name="cpt">Conditional probability table</param>
        /// <returns></returns>
        public static VariableArray<int> AddChildFromOneParent(
            VariableArray<int> parent,
            VariableArray<Vector> cpt)
        {
            var n = parent.Range;
            var child = Variable.Array<int>(n);
            using (Variable.ForEach(n))
            using (Variable.Switch(parent[n]))
            {
                child[n] = Variable.Discrete(cpt[parent[n]]);
            }
            return child;
        }

        public virtual void LoadData(
            string ifn,               // The file name
            out int[] CitizenSciID,   // Citizen  Scientist Unique Label
            //out int[] community,      // Error Community
            out int[] motivation,     // Motivation
            out int[] recruitment,    // Recruitment
            out int[] age,            // Age
            out int[] education,      // Education
            out int[] occupation,     // Occupation
            out int[] ruralurban,     // RuralUrban
            out int[] gender,         // Gender
            out int[] ability,        // Ability
            out int[] experience)     // Experience 
       {
            // File is assumed to have a header row, followed by
            // tab or comma separated fields
            CitizenSciID = null;
            //community = null;
            motivation = null;
            recruitment = null;
            age = null;
            education = null;
            occupation = null;
            ruralurban = null;
            gender = null;
            ability = null;
            experience = null;
            int totalDocs = 0;
            string myStr;
            char[] sep = { '\t', ',' };
            for (int pass = 0; pass < 2; pass++)
            {
                if (1 == pass)
                {
                    CitizenSciID = new int[totalDocs];
                   // community = new int[totalDocs];
                    motivation = new int[totalDocs];
                    recruitment = new int[totalDocs];
                    age = new int[totalDocs];
                    education = new int[totalDocs];
                    occupation = new int[totalDocs];
                    ruralurban = new int[totalDocs];
                    gender = new int[totalDocs];
                    ability = new int[totalDocs];
                    experience = new int[totalDocs];
                    totalDocs = 0;
                }

                using (var mySR = new StreamReader(ifn))
                {
                    mySR.ReadLine(); // Skip over header line
                    while ((myStr = mySR.ReadLine()) != null)
                    {
                        string[] mySplitStr = myStr.Split(sep);

                        // Grabs data
                        if (1 == pass)
                        {
                            int cs = int.Parse(mySplitStr[0]);
                            //int com = int.Parse(mySplitStr[1]);
                            int mot = int.Parse(mySplitStr[2]);
                            int rec = int.Parse(mySplitStr[3]);
                            int ag = int.Parse(mySplitStr[4]);
                            int edu = int.Parse(mySplitStr[5]);
                            int occ = int.Parse(mySplitStr[6]);
                            int ru = int.Parse(mySplitStr[7]);
                            int gen = int.Parse(mySplitStr[8]);
                            int abil = int.Parse(mySplitStr[9]);
                            int exp = int.Parse(mySplitStr[10]);
                            CitizenSciID[totalDocs] = cs;
                            //community[totalDocs] = com;
                            motivation[totalDocs] = mot;
                            recruitment[totalDocs] = rec;
                            age[totalDocs] = ag;
                            education[totalDocs] = edu;
                            occupation[totalDocs] = occ;
                            ruralurban[totalDocs] = ru;
                            gender[totalDocs] = gen;
                            ability[totalDocs] = abil;
                            experience[totalDocs] = exp;
                        }
                        totalDocs++;
                    }
                }
            }           
        }

        public virtual void LoadObsData(
            string ifn_,
            int[] CitizenSciIDArr,
            int numCitizens_,
            out int[] CitizenSciID_,   // ID for each CS
            out double[] csObservation_,  // Submitted CS observations
            out double[] Truevalue_, 
            out double[][] jaggedCSO_,
            out double[][] jaggedTV_,
            out int[][] error_,
            out int[][] cseIndex_)   
        {
            // File is assumed to have a header row, followed by
            // tab or comma separated fields
            CitizenSciID_ = null;
            csObservation_ = null;
            Truevalue_ = null;
            int totalDocs = 0;
            string myStr;
            char[] sep = { '\t', ',' };

            jaggedTV_ = new double[numCitizens_][];
            jaggedCSO_ = new double[numCitizens_][];
            error_ = new int[numCitizens_][];
            cseIndex_ = new int[numCitizens_][];
            int row = 0, csOld = CitizenSciIDArr[0];
            var lstTV = new List<double>();
            var lstCSO = new List<double>();
            var lstEr = new List<int>();
            var lstCSEI = new List<int>();

            for (int pass = 0; pass < 2; pass++)
            {
                if (1 == pass)
                {
                    CitizenSciID_ = new int[totalDocs];
                    csObservation_ = new double[totalDocs];
                    Truevalue_ = new double[totalDocs];
                    totalDocs = 0;
                }

                using (var mySR = new StreamReader(ifn_))
                {
                    mySR.ReadLine(); // Skip over header line
                    while ((myStr = mySR.ReadLine()) != null)
                    {
                        string[] mySplitStr = myStr.Split(sep);

                        // Grabs data
                        if (1 == pass)
                        {
                            int cs = int.Parse(mySplitStr[0]);
                            double cso = double.Parse(mySplitStr[2]);
                            double tv = double.Parse(mySplitStr[1]);
                            int er = int.Parse(mySplitStr[3]);
                            int csei = int.Parse(mySplitStr[4]);
                            CitizenSciID_[totalDocs] = cs;
                            csObservation_[totalDocs] = cso;
                            Truevalue_[totalDocs] = tv;
                            if (cs != csOld)
                            {
                                jaggedTV_[row] = lstTV.ToArray();
                                jaggedCSO_[row] = lstCSO.ToArray();
                                error_[row] = lstEr.ToArray();
                                cseIndex_[row] = lstCSEI.ToArray();
                                lstTV.Clear();
                                lstCSO.Clear();
                                lstEr.Clear();
                                lstCSEI.Clear();
                                lstTV.Add(tv);
                                lstCSO.Add(cso);
                                lstEr.Add(er);
                                lstCSEI.Add(csei);
                                if (row == (numCitizens_ - 2))
                                {
                                    row++;
                                    jaggedTV_[row] = lstTV.ToArray();
                                    jaggedCSO_[row] = lstCSO.ToArray();
                                    error_[row] = lstEr.ToArray();
                                    cseIndex_[row] = lstCSEI.ToArray();
                                    lstTV.Clear();
                                    lstCSO.Clear();
                                    lstEr.Clear();
                                    lstCSEI.Clear();
                                }
                                row++;
                                csOld = cs;
                            }
                            else
                            {
                                lstTV.Add(tv);
                                lstCSO.Add(cso);
                                lstEr.Add(er);
                                lstCSEI.Add(csei);
                            }
                        }
                        totalDocs++;
                    }
                }
            }
        }
    }
    public class CommunityChar
    {
        public static void Main(string[] args)
        {
            int numCommunity = 4;
            int numMotivation = 2;
            int numRecruitment = 4;
            int numAge = 3;
            int numEducation = 3;
            int numOccupation = 3;
            int numRuralUrban = 3;
            int numGender = 2;
            int numAbility = 3;
            int numExperience = 3;
            int numError = 7;
            int numCitizens = 152; // Group 1 & 2 = 73, Group 3 = 152 // 153;          // should pull this from the data
            int numEvents = 6091; // Group 1 = 3015; Group 2 = 3022; Group 3 = 6091  6619;   // also need to pull this from the data somehow
            double[] alphaprior = { 0.25, 0.75, 1.5, 0.5, 50, 15, 8 }; // for precsPrior Gamma distribution
            double[] betaprior = { 0.05, 0.25, 0.05, 0.01, 10, 5, 34 };  // no error, unit error, meniscus error, unknown error
            double meantvprior = 15; 
            double vartvprior = 600;
            double[] meanaprior = { 1, 0.1, 1.002, 0.9, 7, 4, 2 }; // for the regression mix
            double[] varaprior = { 0.5, 0.5, 2.0, 50, 50, 5, 15 };
            double[] meanbprior = { 0, 0.02, 2.3, 4.2, 4.2, 3, 10 };
            double[] varbprior = { 0.5, 0.5, 0.2, 50, 50, 34, 56 };

            InferenceEngine.Visualizer = new WindowsVisualizer();

            // Create a new model
            CommunityCharModel CommChar= new CommunityCharModel();
            CommChar.CreateCommunityCharModel(numCommunity, numMotivation, numRecruitment, numAge, numEducation, numOccupation, numRuralUrban, numGender, numAbility, numExperience, numError, numCitizens, numEvents);

            // Get the arrays of community characteristics
            int[] CitizenSciID;   // Citizen  Scientist Unique Label
            int[] CitizenSciIDChar;
            //int[] community;      // Community
            int[] motivation;     // Motivation
            int[] recruitment;    // Recruitment
            int[] age;            // Age
            int[] education;      // Education
            int[] occupation;     // Occupation
            int[] ruralurban;     // RuralUrban
            int[] gender;         // Gender
            int[] ability;        // Ability
            int[] experience;     // Experience
            int[][] error;
            double[] csObservation;  // Each Citizen Scientist Observation
            double[] Truevalue;    // True value of rainfall data. Taken as equal to the picture.
            double[][] jaggedCSO;
            double[][] jaggedTV;
            int[][] cseIndex;

            string fileName = Path.Combine(
#if NETCORE
                    Path.GetDirectoryName(typeof(CommunityChar).Assembly.Location), // work dir is not the one with Microsoft.ML.Probabilistic.Tests.dll on netcore and neither is .Location on netfull
#endif
                "Data", "Group3TrainChar.txt");
            if (!File.Exists(fileName))
            {
                fileName = Path.Combine(
#if NETCORE
                    Path.GetDirectoryName(typeof(CommunityChar).Assembly.Location), // work dir is not the one with Microsoft.ML.Probabilistic.Tests.dll on netcore and neither is .Location on netfull
#endif
                    "..", "Data", "Group3TrainChar.txt");
            }

            CommChar.LoadData(fileName,
                out CitizenSciIDChar,
                //out community,
                out motivation,
                out recruitment,
                out age,
                out education,
                out occupation,
                out ruralurban,
                out gender,
                out ability,
                out experience);
            
            string fileName2 = Path.Combine(
#if NETCORE
                    Path.GetDirectoryName(typeof(CommunityChar).Assembly.Location), // work dir is not the one with Microsoft.ML.Probabilistic.Tests.dll on netcore and neither is .Location on netfull
#endif
                "Data", "Group3Train.txt"); //CSObsClean
            if (!File.Exists(fileName))
            {
                fileName2 = Path.Combine(
#if NETCORE
                    Path.GetDirectoryName(typeof(CommunityChar).Assembly.Location), // work dir is not the one with Microsoft.ML.Probabilistic.Tests.dll on netcore and neither is .Location on netfull
#endif
                    "..", "Data", "Group3Train.txt");
            }

            CommChar.LoadObsData(fileName2, CitizenSciIDChar, numCitizens, out CitizenSciID, out csObservation, out Truevalue, out jaggedCSO, out jaggedTV, out error, out cseIndex);

            // Uniform dist. placeholders
            Dirichlet DirPriorVal = Dirichlet.Uniform(numCommunity);
            Dirichlet[] DirPrior = new Dirichlet[numCommunity];
            Gaussian[] GauPrior = new Gaussian[numEvents];
            Gamma[] GamPrior = new Gamma[numError];

            for (int i = 0; i < numCommunity; i++)
            {
                DirPrior[i] = Dirichlet.Uniform(numMotivation);

            }
            for (int j = 0; j < numEvents; j++)
            {
                GauPrior[j] = Gaussian.FromMeanAndPrecision(0, 1);
            }
            for (int t = 0; t < (numError); t++)
            {
                GamPrior[t] = Gamma.FromShapeAndRate(1, 0.5);
            }

            CommChar.LearnParameters("train", motivation, recruitment, age, education, occupation, ruralurban, gender, ability, experience, error, jaggedCSO, csObservation, csObservation, alphaprior, betaprior, meantvprior, vartvprior, meanaprior, varaprior, meanbprior, varbprior, Truevalue, Truevalue, cseIndex,
                DirPriorVal, DirPrior, DirPrior, DirPrior, DirPrior, DirPrior, DirPrior, DirPrior, DirPrior, DirPrior, DirPrior, GauPrior, GauPrior, GauPrior, GamPrior);

            /////////////////////////////////////////////////////
            ///////////////////Testing Data//////////////////////
            /////////////////////////////////////////////////////

            int numEvents_test = 528;  // MultObsTest1 = 22; // Group 1 Test = 262; Group 2 Test = 320
            int numCitizens_test = 110;      // MultObsTest1Char = 21; // Group 1 Test = 60; Group 2 Test = 7

            CommunityCharModel CommCharTest = new CommunityCharModel();
            CommCharTest.CreateCommunityCharModel(numCommunity, numMotivation, numRecruitment, numAge, numEducation, numOccupation, numRuralUrban, numGender, numAbility, numExperience, numError, numCitizens_test, numEvents_test);

            // Get the arrays of community characteristics
            int[] CitizenSciID_test;   // Citizen Scientist Unique Label
            int[] CitizenSciID_testChar;   // Citizen Scientist Unique Label
            //int[] community;      // Community
            int[] motivation_test;     // Motivation
            int[] recruitment_test;    // Recruitment
            int[] age_test;            // Age
            int[] education_test;      // Education
            int[] occupation_test;     // Occupation
            int[] ruralurban_test;     // RuralUrban
            int[] gender_test;         // Gender
            int[] ability_test;        // Ability
            int[] experience_test;     // Experience
            int[][] error_test;
            double[] csObservation_test;  // Each Citizen Scientist Observation
            double[] Truevalue_test;      // True value of rainfall data. Taken as equal to the picture.
            double[][] jaggedCSO_test;
            double[][] jaggedTV_test;
            int[][] cseIndex_test;

            string fileName_test = Path.Combine(
#if NETCORE
                    Path.GetDirectoryName(typeof(CommunityChar).Assembly.Location), // work dir is not the one with Microsoft.ML.Probabilistic.Tests.dll on netcore and neither is .Location on netfull
#endif
                "Data", "Group3TestChar.txt");
            if (!File.Exists(fileName_test))
            {
                fileName_test = Path.Combine(
#if NETCORE
                    Path.GetDirectoryName(typeof(CommunityChar).Assembly.Location), // work dir is not the one with Microsoft.ML.Probabilistic.Tests.dll on netcore and neither is .Location on netfull
#endif
                    "..", "Data", "Group3TestChar.txt");
            }

            CommCharTest.LoadData(fileName_test,
                out CitizenSciID_testChar,
                //out community,
                out motivation_test,
                out recruitment_test,
                out age_test,
                out education_test,
                out occupation_test,
                out ruralurban_test,
                out gender_test,
                out ability_test,
                out experience_test);

            //int numCitizens_test = motivation.Length;

            string fileName2_test = Path.Combine(
#if NETCORE
                    Path.GetDirectoryName(typeof(CommunityChar).Assembly.Location), // work dir is not the one with Microsoft.ML.Probabilistic.Tests.dll on netcore and neither is .Location on netfull
#endif
                "Data", "Group3Test.txt"); //CSObsClean
            if (!File.Exists(fileName2_test))
            {
                fileName2_test = Path.Combine(
#if NETCORE
                    Path.GetDirectoryName(typeof(CommunityChar).Assembly.Location), // work dir is not the one with Microsoft.ML.Probabilistic.Tests.dll on netcore and neither is .Location on netfull
#endif
                    "..", "Data", "Group3Test.txt");
            }

            CommCharTest.LoadObsData(fileName2_test, CitizenSciID_testChar, numCitizens_test, out CitizenSciID_test, out csObservation_test, out Truevalue_test, out jaggedCSO_test, out jaggedTV_test, out error_test, out cseIndex_test);

            //int numEvents_test = csObservation_test.Length;

            CommCharTest.LearnParameters("test", motivation_test, recruitment_test, age_test, education_test, occupation_test, ruralurban_test, gender_test, ability_test, experience_test, error_test, jaggedCSO_test, csObservation, csObservation_test, alphaprior, betaprior, meantvprior, vartvprior, meanaprior, varaprior, meanbprior, varbprior, Truevalue, Truevalue_test, cseIndex_test,
        CommChar.ProbCommunityPosterior,
        CommChar.CPTMotivationPosterior,
        CommChar.CPTRecruitmentPosterior,
        CommChar.CPTAgePosterior,
        CommChar.CPTEducationPosterior,
        CommChar.CPTOccupationPosterior,
        CommChar.CPTRuralUrbanPosterior,
        CommChar.CPTGenderPosterior,
        CommChar.CPTAbilityPosterior,
        CommChar.CPTExperiencePosterior,
        CommChar.CPTErrorPosterior,
        CommChar.TrueValuePosterior,
        CommChar.aSlopePosterior,
        CommChar.bIntPosterior,
        CommChar.PrecsPosterior);

            /////////////////////////////////////////////////////////////////////////////////////////

            Console.WriteLine("\n*********************************************");
            Console.WriteLine("Learning parameters from data (uniform prior)");
            Console.WriteLine("*********************************************");

            // Print out the Results 
            Console.WriteLine("\nCommunity Probability");
            Console.WriteLine(CommChar.ProbCommunityPosterior.GetMean());
            
            var lstCS_Com = new List<double>();
            Console.WriteLine("Community Statistics");
            for (int i = 0; i < numCitizens; i++)
            {
                lstCS_Com.Add(CommChar.CommunityPosterior[i].GetMode());
                //Console.WriteLine(CommChar.CommunityPosterior[i].GetMode()); //prints out community of CS i
            }
            var g = lstCS_Com.GroupBy(i => i);

            Console.WriteLine("{0,-10} {1,-10} {2,-10:F2}","Community","CS Count", "Prob.");
            foreach (var grp in g)
            {
                Console.WriteLine("{0,-10} {1,-10} {2,-10:F2}", grp.Key, grp.Count(), (grp.Count()/Convert.ToDouble(numCitizens)).ToString("F2"));
            }
            
            char[] sep = { ',' };
            string errors;
            errors = "0,1,2,3,4,5,6";
            string[] mySplitStrEr = errors.Split(sep);
            Console.WriteLine("\nRegression Posteriors");
            Console.WriteLine("{0,-12}{1,-10}{2,-10}{3,-10}", "Error Type", "aSlope", "bInt", "Precision");
            for (int i = 0; i < (numError); i++)
            {
                Console.WriteLine(
                    "{0,-12}{1,-10:F3}{2,-10:F3}{3,-10:F3}",
                    mySplitStrEr[i],
                    CommChar.aSlopePosterior[i].GetMean().ToString("F3"),
                    CommChar.bIntPosterior[i].GetMean().ToString("F3"),
                    CommChar.PrecsPosterior[i].GetMean().ToString("F3"));
            }

            //Console.WriteLine(CommChar.aSlopePosterior[3]);
            //Console.WriteLine(CommChar.bIntPosterior[3]);

            //char[] sep = {','};
            string communities;
            communities ="0,1,2,3";
            string[] mySplitStr = communities.Split(sep);

            Console.WriteLine("{0,-28}{1,-15}{2,-20}{3,-15}{4,-15}{5,-15}{6,-15}{7,-15}", "\nError CPT", "0", "1", "2", "3", "4", "5", "6");
            for (int i = 0; i < numCommunity; i++)
            {
                Console.WriteLine(
                    "{0,-13}{1,-15}{2,-15:F2}{3,-20:F3}{4,-15:F3}{5,-15:F3}{6,-15:F3}{7,-15:F3}{8,-15:F3}",
                    "Prob. Error | ",
                    mySplitStr[i],
                    CommChar.CPTErrorPosterior[i].GetMean()[0].ToString("F3"),
                    CommChar.CPTErrorPosterior[i].GetMean()[1].ToString("F3"),
                    CommChar.CPTErrorPosterior[i].GetMean()[2].ToString("F3"),
                    CommChar.CPTErrorPosterior[i].GetMean()[3].ToString("F3"),
                    CommChar.CPTErrorPosterior[i].GetMean()[4].ToString("F3"),
                    CommChar.CPTErrorPosterior[i].GetMean()[5].ToString("F3"),
                    CommChar.CPTErrorPosterior[i].GetMean()[6].ToString("F3"));
            }

            Console.WriteLine("{0,-28}{1,-15}{2,-15}", "\nMotivation CPT", "Volunteer", "Paid");
            for (int i = 0; i < numCommunity; i++)
            {
                Console.WriteLine(
                    "{0,-13}{1,-15}{2,-15:F3}{3,-15:F3}",
                    "Prob. Mot. | ",
                    mySplitStr[i],
                    CommChar.CPTMotivationPosterior[i].GetMean()[0].ToString("F3"),
                    CommChar.CPTMotivationPosterior[i].GetMean()[1].ToString("F3"));
            }

            Console.WriteLine("{0,-28}{1,-15}{2,-20}{3,-15}{4,-15}", "\nRecruitment CPT", "Outreach", "PersonalConnection", "RandomVisit", "SocialMedia");
            for (int i = 0; i < numCommunity; i++)
            {
                Console.WriteLine(
                    "{0,-13}{1,-15}{2,-15:F3}{3,-20:F3}{4,-15:F3}{5,-15:F3}",
                    "Prob. Rec. | ",
                    mySplitStr[i],
                    CommChar.CPTRecruitmentPosterior[i].GetMean()[0].ToString("F3"),
                    CommChar.CPTRecruitmentPosterior[i].GetMean()[1].ToString("F3"),
                    CommChar.CPTRecruitmentPosterior[i].GetMean()[2].ToString("F3"),
                    CommChar.CPTRecruitmentPosterior[i].GetMean()[3].ToString("F3"));
            }

            Console.WriteLine("{0,-28}{1,-15}{2,-15}{3,-15}", "\nAge CPT", "<=18", "19-25", ">25");
            for (int i = 0; i < numCommunity; i++)
            {
                Console.WriteLine(
                    "{0,-13}{1,-15}{2,-15:F3}{3,-15:F3}{4,-15:F3}",
                    "Prob. Age| ",
                    mySplitStr[i],
                    CommChar.CPTAgePosterior[i].GetMean()[0].ToString("F3"),
                    CommChar.CPTAgePosterior[i].GetMean()[1].ToString("F3"),
                    CommChar.CPTAgePosterior[i].GetMean()[2].ToString("F3"));
            }

            Console.WriteLine("{0,-28}{1,-15}{2,-15}{3,-15}", "\nEducation CPT", "<Bachelors", "Bachelors", ">Bachelors");
            for (int i = 0; i < numCommunity; i++)
            {
                Console.WriteLine(
                    "{0,-13}{1,-15}{2,-15:F3}{3,-15:F3}{4,-15:F3}",
                    "Prob. Edu.| ",
                    mySplitStr[i],
                    CommChar.CPTEducationPosterior[i].GetMean()[0].ToString("F3"),
                    CommChar.CPTEducationPosterior[i].GetMean()[1].ToString("F3"),
                    CommChar.CPTEducationPosterior[i].GetMean()[2].ToString("F3"));
            }

            Console.WriteLine("{0,-28}{1,-15}{2,-15}{3,-15}", "\nOccupation CPT", "Agriculture", "Student", "Other");
            for (int i = 0; i < numCommunity; i++)
            {
                Console.WriteLine(
                    "{0,-13}{1,-15}{2,-15:F3}{3,-15:F3}{4,-15:F3}",
                    "Prob. Occ.| ",
                    mySplitStr[i],
                    CommChar.CPTOccupationPosterior[i].GetMean()[0].ToString("F3"),
                    CommChar.CPTOccupationPosterior[i].GetMean()[2].ToString("F3"),
                    CommChar.CPTOccupationPosterior[i].GetMean()[1].ToString("F3"));
            }

            Console.WriteLine("{0,-30}{1,-15}{2,-15}{3,-15}", "\nRuralUrban CPT", "Rural", "Semi-Urban", "Urban");
            for (int i = 0; i < numCommunity; i++)
            {
                Console.WriteLine(
                    "{0,-15}{1,-15}{2,-15:F3}{3,-15:F3}{4,-15:F3}",
                    "Prob. RurUrb| ",
                    mySplitStr[i],
                    CommChar.CPTRuralUrbanPosterior[i].GetMean()[0].ToString("F3"),
                    CommChar.CPTRuralUrbanPosterior[i].GetMean()[1].ToString("F3"),
                    CommChar.CPTRuralUrbanPosterior[i].GetMean()[2].ToString("F3"));
            }

            Console.WriteLine("{0,-28}{1,-15}{2,-15}", "\nGender CPT", "Female", "Male");
            for (int i = 0; i < numCommunity; i++)
            {
                Console.WriteLine(
                    "{0,-13}{1,-15}{2,-15:F3}{3,-15:F3}",
                    "Prob. Gen.| ",
                    mySplitStr[i],
                    CommChar.CPTGenderPosterior[i].GetMean()[0].ToString("F3"),
                    CommChar.CPTGenderPosterior[i].GetMean()[1].ToString("F3"));
            }

            Console.WriteLine("{0,-30}{1,-15}{2,-15}{3,-15}", "\nAbility CPT", "<70%", "70-90%", ">90%");
            for (int i = 0; i < numCommunity; i++)
            {
                Console.WriteLine(
                    "{0,-15}{1,-15}{2,-15:F3}{3,-15:F3}{4,-15:F3}",
                    "Prob. Abil.| ",
                    mySplitStr[i],
                    CommChar.CPTAbilityPosterior[i].GetMean()[0].ToString("F3"),
                    CommChar.CPTAbilityPosterior[i].GetMean()[1].ToString("F3"),
                    CommChar.CPTAbilityPosterior[i].GetMean()[2].ToString("F3"));
            }

            Console.WriteLine("{0,-52}", "\nObservations");
            Console.WriteLine("{0,-30}{1,-15}{2,-15}{3,-15}", "\nExperience CPT", "<28", "27-53", ">53");
            for (int i = 0; i < numCommunity; i++)
            {
                Console.WriteLine(
                    "{0,-15}{1,-15}{2,-15:F3}{3,-15:F3}{4,-15:F3}",
                    "Prob. Exp.| ",
                    mySplitStr[i],
                    CommChar.CPTExperiencePosterior[i].GetMean()[0].ToString("F3"),
                    CommChar.CPTExperiencePosterior[i].GetMean()[1].ToString("F3"),
                    CommChar.CPTExperiencePosterior[i].GetMean()[2].ToString("F3"));
            }

            //Writes the enclosed lines to a text file --> too many lines to display in console
            FileStream output1 = new FileStream("ConsoleOutputTrain.txt", FileMode.Create);
            TextWriter outSave = Console.Out;
            StreamWriter portal = new StreamWriter(output1);
            Console.SetOut(portal);

            Console.WriteLine("Inferred Communities");
            for (int i = 0; i < numCitizens; i++)
            {
               Console.WriteLine(
                        "{0,-15}{1,-15}{2,-15}",
                        i,
                        CitizenSciIDChar[i],
                        CommChar.CommunityPosterior[i].GetMode());
            }

            Console.WriteLine("\nInferred Errors");
            for (int i = 0; i < numCitizens; i++)
            {
                for (int j = 0; j < cseIndex[i].Length; j++)
                {
                    Console.WriteLine(
                        "{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}",
                        i, j,
                        CommChar.ErrorPosterior[i][j].GetMode(),
                        jaggedCSO[i][j],
                        jaggedTV[i][j]);
                }
            }
            Console.SetOut(outSave);
            portal.Close();

            Console.WriteLine("\n*********************************************");
            Console.WriteLine("Predicting parameters from Posteriors");
            Console.WriteLine("*********************************************");

            Console.WriteLine("\nRegression Posteriors TEST");
            Console.WriteLine("{0,-12}{1,-10}{2,-10}{3,-10}", "Error Type", "aSlope", "bInt", "Precision");
            for (int i = 0; i < (numError); i++)
            {
                Console.WriteLine(
                    "{0,-12}{1,-10:F3}{2,-10:F3}{3,-10:F3}",
                    mySplitStrEr[i],
                    CommCharTest.aSlopePosterior[i].GetMean().ToString("F3"),
                    CommCharTest.bIntPosterior[i].GetMean().ToString("F3"),
                    CommCharTest.PrecsPosterior[i].GetMean().ToString("F3"));
            }

            //Writes the enclosed lines to a text file --> too many lines to display in console
            FileStream output1_Test = new FileStream("ConsoleOutputTest.txt", FileMode.Create);
            TextWriter outSave_Test = Console.Out;
            StreamWriter portal_Test = new StreamWriter(output1_Test);
            Console.SetOut(portal_Test);

            Console.WriteLine("Inferred Communities");
            for (int i = 0; i < numCitizens_test; i++)
            {
                Console.WriteLine(
                         "{0,-15}{1,-15}{2,-15}",
                         i,
                         CitizenSciID_testChar[i],
                         CommCharTest.CommunityPosterior[i].GetMode());
            }

            Console.WriteLine("\nInferred Errors");
            for (int i = 0; i < numCitizens_test; i++)
            {
                for (int j = 0; j < cseIndex_test[i].Length; j++)
                {
                    Console.WriteLine(
                        "{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}",
                        i, j,
                        CommCharTest.ErrorPosterior[i][j],
                        CommCharTest.ErrorPosterior[i][j].GetMode(),
                        jaggedCSO_test[i][j],
                        jaggedTV_test[i][j]);
                }
            }

            //Console.WriteLine("\nInferred True Values");
            //for (int i = 0; i < numEvents_test; i++)
            //{
            //    Console.WriteLine(
            //             "{0,-15}{1,-15}{2,-15}{3,-15}",
            //             i,
            //             CitizenSciID_test[i],
            //             CommCharTest.TrueValuePosterior[i],
            //             CommCharTest.TrueValuePosterior[i].GetMean());
            //}

            Console.WriteLine("\nInferred CSObs");
            for (int i = 0; i < numCitizens_test; i++)
            {
                for (int j = 0; j < cseIndex_test[i].Length; j++)
                {
                    Console.WriteLine(
                         "{0,-15}{1,-15}{2,-15}{3,-15}",
                         i,
                         CitizenSciID_test[i],
                         CommCharTest.CSobservationPosterior[i][j],
                         CommCharTest.CSobservationPosterior[i][j].GetMean());
                }
            }
            Console.SetOut(outSave_Test);
            portal.Close();
        }
    }
}




